package com.example.qrattendance.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.example.qrattendance.MainActivity
import com.example.qrattendance.QRAttendanceApp
import com.example.qrattendance.R
import com.example.qrattendance.viewmodel.AuthViewModel
import com.example.qrattendance.viewmodel.AuthViewModelFactory

class RegisterActivity : AppCompatActivity() {

    private lateinit var authViewModel: AuthViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val repository = (application as QRAttendanceApp).repository
        authViewModel = ViewModelProvider(this, AuthViewModelFactory(repository))[AuthViewModel::class.java]

        val etName     = findViewById<TextInputEditText>(R.id.etName)
        val etEmail    = findViewById<TextInputEditText>(R.id.etEmail)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val rgRole     = findViewById<RadioGroup>(R.id.rgRole)
        val btnRegister= findViewById<MaterialButton>(R.id.btnRegister)
        val tvBack     = findViewById<TextView>(R.id.tvBack)
        val tvLogin    = findViewById<TextView>(R.id.tvLogin)

        btnRegister.setOnClickListener {
            val role = if (rgRole.checkedRadioButtonId == R.id.rbTeacher) "teacher" else "student"
            authViewModel.register(
                etName.text.toString().trim(),
                etEmail.text.toString().trim(),
                etPassword.text.toString().trim(),
                role
            )
        }

        tvBack.setOnClickListener { finish() }
        tvLogin.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        authViewModel.registerResult.observe(this) { success ->
            if (success) {
                Toast.makeText(this, "Account created! Please login.", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }

        authViewModel.errorMessage.observe(this) { message ->
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }
}
